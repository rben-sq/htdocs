<?php
		include_once("config.php");
        var_dump($_FILES['poster']);
    ?>
        